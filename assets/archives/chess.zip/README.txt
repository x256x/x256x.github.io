(c) 2023 x256x
これはチェス用のテクスチャです
前提としてOptifineが必要で
骨粉(白)とイカスミ(黒)に名前をつけることで適用されます
使用できる名前のリスト:
ビショップ	, キング, ナイト, ポーン, クイーン, ルーク

チェス駒のテクスチャはPixel Chess Piecesをリサイズして使用しました
Lucas312 さんの作品 Pixel Chess Pieces は CC BY-SA 3.0の下に提供されています
https://opengameart.org/users/lucas312
https://opengameart.org/content/pixel-chess-pieces
https://creativecommons.org/licenses/by-sa/3.0